<?php
// Include the database connection file
include("./Database/DB.php");

// Retrieve the filter values
$selected_city = $_POST["city"];
$selected_year = $_POST["year"];
$selected_reason = $_POST["reason"];

// Construct the SQL query with filters
$query = "SELECT 
            dropout_reasons.reason, 
            dropout_stu.dr_year, 
            school.district,
            COUNT(DISTINCT dropout_stu.aadhar_no) AS dropout_students,
            COUNT(DISTINCT dropout_stu.school_id) AS schools_with_dropout
          FROM 
            dropout_stu 
          INNER JOIN 
            school ON dropout_stu.school_id = school.school_id  
          INNER JOIN 
            student ON dropout_stu.aadhar_no = student.aadhar_no 
          INNER JOIN 
            dropout_reasons ON dropout_stu.drop_re_id = dropout_reasons.drop_re_id";

// Apply filters
$where_conditions = [];
if ($selected_city != "Select District") {
    $where_conditions[] = "school.district = '$selected_city'";
}
if ($selected_year != "Select Year") {
    $where_conditions[] = "dropout_stu.dr_year = '$selected_year'";
}
if ($selected_reason != "Select Reason") {
    $where_conditions[] = "dropout_stu.drop_re_id = '$selected_reason'";
}

if (!empty($where_conditions)) {
    $query .= " WHERE " . implode(" AND ", $where_conditions);
}

// Group by district, year, and reason for dropout
$query .= " GROUP BY school.district, dropout_stu.dr_year, dropout_reasons.reason";

// Execute the query
$result = mysqli_query($conn, $query);

// Process the result into an array
$data = [];
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = [
        'district' => $row['district'],
        'year' => $row['dr_year'],
        'reason' => $row['reason'],
        'dropout_students' => $row['dropout_students'],
        'schools_with_dropout' => $row['schools_with_dropout']
    ];
}

// Convert the data array to JSON and echo it
echo json_encode($data);

// Close the database connection
mysqli_close($conn);
?>
