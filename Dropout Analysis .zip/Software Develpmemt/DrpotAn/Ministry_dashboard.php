<?php
include("./Database/DB.php");
session_start();
if (!isset($_SESSION['ministry_email'])) {
    header("Location: Ministry_login_1.php");
    exit();
}

// Default query to fetch all data
$query = "SELECT 
dropout_reasons.reason, 
dropout_stu.dr_year, 
school.district,
COUNT(DISTINCT dropout_stu.aadhar_no) AS dropout_students,
COUNT(DISTINCT dropout_stu.school_id) AS schools_with_dropout
FROM 
dropout_stu 
INNER JOIN 
school ON dropout_stu.school_id = school.school_id  
INNER JOIN 
student ON dropout_stu.aadhar_no = student.aadhar_no 
INNER JOIN 
dropout_reasons ON dropout_stu.drop_re_id = dropout_reasons.drop_re_id";

// If Apply button is clicked, apply filters
if (isset($_POST["Apply"])) {
    // Get selected values from the form
    $selected_city = $_POST["city"];
    $selected_year = $_POST["year"];
    $selected_reason = $_POST["reason"];

    // Add WHERE conditions based on selected filters
    $where_conditions = [];
    if ($selected_city != "Select District") {
        $where_conditions[] = "school.district = '$selected_city'";
    }
    if ($selected_year != "Select Year") {
        $where_conditions[] = "dropout_stu.dr_year = '$selected_year'";
    }
    if ($selected_reason != "Select Reason") {
        $where_conditions[] = "dropout_stu.drop_re_id = '$selected_reason'";
    }

    // Add WHERE conditions to the query if filters are selected
    if (!empty($where_conditions)) {
        $query .= " WHERE " . implode(" AND ", $where_conditions);
    }
}

// Group by district, year, and reason for dropout
$query .= " GROUP BY school.district, dropout_stu.dr_year, dropout_reasons.reason";

// Execute the query
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.css">
    <title>Dropout Report</title>
</head>
<body>
    <div class="container">
        <!-- First Div: Title -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Dropout Report</a>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="add_school.php">Add School</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Second Div: Dropdowns and Apply Button -->
        <div class="mt-4">
        <form id="filterForm" method="post" >
            <div class="row justify-content-center">
                <div class="col-md-3">
                    <select class="form-select" name="city">
                        <option>Select District</option>
                        <?php
                            // Fetch and display distinct districts from the school database
                            $query_districts = "SELECT DISTINCT school.district FROM dropout_stu INNER JOIN school ON dropout_stu.school_id = school.school_id";
                            $result_districts = mysqli_query($conn, $query_districts);
                            while ($row_district = mysqli_fetch_assoc($result_districts)) {
                                echo "<option>" . $row_district['district'] . "</option>";
                            }
                            ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <select class="form-select" name="year">
                        <option>Select Year</option>
                        <?php
                            // Fetch and display distinct years from the dropout_stu database
                            $query_years = "SELECT DISTINCT dr_year FROM dropout_stu";
                            $result_years = mysqli_query($conn, $query_years);
                            while ($row_year = mysqli_fetch_assoc($result_years)) {
                                echo "<option>" . $row_year['dr_year'] . "</option>";
                            }
                            ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <select class="form-select" name="reason">
                        <option>Select Reason</option>
                        <?php
        // Fetch and display reasons from the dropout_stu table using their IDs
        $query_reasons = "SELECT DISTINCT dropout_reasons.drop_re_id, dropout_reasons.reason 
                          FROM dropout_stu 
                          INNER JOIN dropout_reasons ON dropout_stu.drop_re_id = dropout_reasons.drop_re_id";
        $result_reasons = mysqli_query($conn, $query_reasons);
        while ($row_reason = mysqli_fetch_assoc($result_reasons)) {
            echo "<option value='" . $row_reason['drop_re_id'] . "'>" . $row_reason['reason'] . "</option>";
        }
        ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary" name="Apply">Apply</button>
                </div>
            </div>
        </form>
        </div>
        <!-- Third Div: Charts and Graphs -->
       
        <!-- Fourth Div: Table -->
        <div class="mt-4">
            <table class="table">
                <thead>
                    <tr>
                        <th>District</th>
                        <th>Year</th>
                        <th>Reason of Dropout</th>
                        <th>No. of Dropout Students</th>
                        <th>No of School</th>
                        <th>More Info</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $total_students = 0;
                    $total_schools = 0;
                    if (isset($result)) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . $row['district'] . "</td>";
                            echo "<td>" . $row['dr_year'] . "</td>";
                            echo "<td>" . $row['reason'] . "</td>";
                            echo "<td>" . $row['dropout_students'] . "</td>";
                            echo "<td>" . $row['schools_with_dropout'] . "</td>";
                            echo "<td><a href='more_info.php?district=" . urlencode($row['district']) . "&year=" . urlencode($row['dr_year']) . "&reason=" . urlencode($row['reason']) . "'>More Info</a></td>";
                            echo "</tr>";
                            // Accumulate total students and total schools
                            $total_students += $row['dropout_students'];
                            $total_schools += $row['schools_with_dropout'];
                        }
                    }
                    ?>
                </tbody>
                <!-- Display total students and total schools in the footer row -->
                <tfoot>
                    <tr>
                        <td colspan="3" class="text-end"><strong>Total:</strong></td>
                        <td><?php echo $total_students; ?></td>
                        <td><?php echo $total_schools; ?></td>
                        <td></td> <!-- Leave empty for the More Info column -->
                    </tr>
                </tfoot>
            </table>
        </div>
        <div class="mt-4">
    <form method="post" action="generate_report.php">
        <button type="submit" class="btn btn-primary" name="generate_report">Generate Report</button>
    </form>
</div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>
    
</body>
</html>
