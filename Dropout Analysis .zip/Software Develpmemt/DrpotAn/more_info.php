<?php
// Include the database connection file
include("./Database/DB.php");
session_start();

// Check if the session variable is set
if (!isset($_SESSION['ministry_email'])) {
    header("Location: Ministry_login_1.php");
    exit();
}

// Check if parameters are set in the URL
if(isset($_GET['district']) && isset($_GET['year']) && isset($_GET['reason'])) {
    // Sanitize and store the parameters
    $district = isset($_GET['district']) ? mysqli_real_escape_string($conn, $_GET['district']) : '';
    $year = isset($_GET['year']) ? mysqli_real_escape_string($conn, $_GET['year']) : '';
    $reason_name = isset($_GET['reason']) ? mysqli_real_escape_string($conn, $_GET['reason']) : '';

    // Query to retrieve the reason ID based on the reason name
    $query_reason = "SELECT drop_re_id FROM dropout_reasons WHERE reason = '$reason_name'";
    $result_reason = mysqli_query($conn, $query_reason);

    // Check if the reason exists
    if(mysqli_num_rows($result_reason) > 0) {
        $row_reason = mysqli_fetch_assoc($result_reason);
        $reason = $row_reason['drop_re_id'];

        // Query to retrieve student information including school name based on parameters
        $query = "SELECT student.*, school.name AS school_name
                  FROM student 
                  INNER JOIN dropout_stu ON student.aadhar_no = dropout_stu.aadhar_no
                  INNER JOIN school ON student.school_id = school.school_id
                  WHERE student.district = '$district' AND dropout_stu.dr_year = '$year' AND dropout_stu.drop_re_id = '$reason'";
        
        // Execute the query
        $result = mysqli_query($conn, $query);

        // Check for errors
        if (!$result) {
            echo "Error: " . mysqli_error($conn);
            exit();
        }

        // Count the number of students found
        $num_students = mysqli_num_rows($result);
        ?>

        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
            <title>Student Information</title>
        </head>
        <body>
            <div class="container mt-5">
                <a href="Ministry_dashboard.php" class="btn btn-primary mb-3">Back to Dashboard</a>
                <h2>Student Information</h2>
                <!-- Display the number of students -->
                <p>Number of Students: <?php echo $num_students; ?></p>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Roll No</th>
                            <th>Name</th>
                            <th>Date of Birth</th>
                            <th>Address</th>
                            <th>District</th>
                            <th>Religion</th>
                            <th>Caste</th>
                            <th>Gender</th>
                            <th>School Name</th> <!-- Added school name column -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Check if there are any rows returned by the query
                        if($num_students > 0) {
                            // Output data of each row
                            while($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>" . $row['roll_no'] . "</td>";
                                echo "<td>" . $row['name'] . "</td>";
                                echo "<td>" . $row['d_o_b'] . "</td>";
                                echo "<td>" . $row['address'] . "</td>";
                                echo "<td>" . $row['district'] . "</td>";
                                echo "<td>" . $row['religion'] . "</td>";
                                echo "<td>" . $row['caste'] . "</td>";
                                echo "<td>" . $row['gender'] . "</td>";
                                echo "<td>" . $row['school_name'] . "</td>"; // Added school name column
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='8'>No student information found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </body>
        </html>

        <?php
        // Close the database connection
        mysqli_close($conn);
    } else {
        // Redirect if reason does not exist
        header("Location: error.php");
        exit();
    }
} else {
    // Redirect if parameters are not set
    header("Location: error.php");
    exit();
}
?>
