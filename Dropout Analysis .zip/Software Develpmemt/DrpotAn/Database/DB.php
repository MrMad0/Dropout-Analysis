<?php
 $dbhost = "localhost";
 $dbuser = "root";
 $dbpass = "";
 $dbname = "dropoutanl";
 $conn =mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);


?>