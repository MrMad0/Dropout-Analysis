-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2024 at 05:29 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dropoutanl`
--

-- --------------------------------------------------------

--
-- Table structure for table `dropout_reasons`
--

CREATE TABLE `dropout_reasons` (
  `drop_re_id` int(10) NOT NULL,
  `reason` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dropout_reasons`
--

INSERT INTO `dropout_reasons` (`drop_re_id`, `reason`) VALUES
(1, 'Financial Issues'),
(2, 'Health Issues'),
(3, 'Family Problems'),
(4, 'Lack of Interest'),
(5, 'Poor Academic Performance'),
(6, 'Bullying'),
(7, 'Peer Pressure'),
(8, 'Substance Abuse'),
(9, 'Mental Health Issues'),
(10, 'Physical Disabilities');

-- --------------------------------------------------------

--
-- Table structure for table `dropout_stu`
--

CREATE TABLE `dropout_stu` (
  `d_id` int(10) NOT NULL,
  `school_id` int(10) NOT NULL,
  `dr_year` int(10) NOT NULL,
  `aadhar_no` varchar(13) NOT NULL,
  `drop_re_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dropout_stu`
--

INSERT INTO `dropout_stu` (`d_id`, `school_id`, `dr_year`, `aadhar_no`, `drop_re_id`) VALUES
(19, 1, 2024, '586505920015', 1),
(20, 2, 2024, '874818749393', 1),
(21, 2, 2024, '876219608506', 2),
(22, 1, 2024, '459821596210', 3),
(23, 4, 2024, '979720498084', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ministry`
--

CREATE TABLE `ministry` (
  `minist_id` int(10) NOT NULL,
  `email_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ministry`
--

INSERT INTO `ministry` (`minist_id`, `email_id`) VALUES
(1, 'kanthariyahimesh@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

CREATE TABLE `school` (
  `school_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_no` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `school`
--

INSERT INTO `school` (`school_id`, `name`, `district`, `address`, `email`, `phone_no`) VALUES
(1, 'St. Xavier Public School', 'Surat', '123 Street, City, State, India', 'kanthariyahimesh9098+one@gmail.com', 1234567890),
(2, 'City Montessori School', 'Vadodara', '456 Road, City, State, India', 'kanthariyahimesh9098+two@gmail.com', 2147483647),
(3, 'Delhi Public School', 'Ahmedabad', '789 Avenue, City, State, India', 'kanthariyahimesh9098+three@gmail.com', 2147483647),
(4, 'Lokmanya School', 'Surat', 'Rander, Surat', 'kanthariyahimesh9098+four@gmail.com', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `aadhar_no` varchar(13) NOT NULL,
  `roll_no` varchar(255) NOT NULL,
  `school_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `d_o_b` date NOT NULL,
  `address` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `religion` varchar(255) NOT NULL,
  `caste` enum('SC','ST','OBC','General') NOT NULL,
  `standard` int(10) NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`aadhar_no`, `roll_no`, `school_id`, `name`, `d_o_b`, `address`, `district`, `religion`, `caste`, `standard`, `gender`, `status`) VALUES
('459625607805', 'S002', 1, 'Amit Patel', '2005-11-10', '789, PQR Colony', 'Surat', 'Hindu', 'OBC', 4, 'Male', 'Active'),
('459821596210', 'S003', 1, 'Deepika Singh', '2006-08-03', '987, LMN Avenue', 'Surat', 'Hindu', 'SC', 5, 'Female', 'Dropped'),
('586505920015', 'S012', 1, 'Priya Sharma', '2006-02-28', '456, XYZ Road', 'Surat', 'Hindu', 'General', 3, 'Female', 'Dropped'),
('874818749393', 'S001', 2, 'Ramesh Kumar', '2005-05-15', '123, ABC Street', 'Vadodara', 'Hindu', 'ST', 1, 'Male', 'Dropped'),
('876219608506', 'S013', 2, 'Rajesh Gupta', '2005-04-20', '654, DEF Lane', 'Vadodara', 'Hindu', 'General', 4, 'Male', 'Dropped'),
('979720498084', 'S111', 4, 'himesh kanthariya', '2005-03-30', 'Jahangirpura', 'Surat', 'Hindu', 'SC', 10, 'Male', 'Dropped');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dropout_reasons`
--
ALTER TABLE `dropout_reasons`
  ADD PRIMARY KEY (`drop_re_id`);

--
-- Indexes for table `dropout_stu`
--
ALTER TABLE `dropout_stu`
  ADD PRIMARY KEY (`d_id`),
  ADD KEY `school_no` (`school_id`),
  ADD KEY `drop_re_id` (`drop_re_id`),
  ADD KEY `aadhar_no` (`aadhar_no`);

--
-- Indexes for table `ministry`
--
ALTER TABLE `ministry`
  ADD PRIMARY KEY (`minist_id`);

--
-- Indexes for table `school`
--
ALTER TABLE `school`
  ADD PRIMARY KEY (`school_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`aadhar_no`),
  ADD UNIQUE KEY `roll_no` (`roll_no`),
  ADD UNIQUE KEY `aadhar_no` (`aadhar_no`),
  ADD KEY `school_id` (`school_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dropout_stu`
--
ALTER TABLE `dropout_stu`
  MODIFY `d_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `ministry`
--
ALTER TABLE `ministry`
  MODIFY `minist_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `school`
--
ALTER TABLE `school`
  MODIFY `school_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dropout_stu`
--
ALTER TABLE `dropout_stu`
  ADD CONSTRAINT `dropout_stu_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `school` (`school_id`),
  ADD CONSTRAINT `dropout_stu_ibfk_2` FOREIGN KEY (`drop_re_id`) REFERENCES `dropout_reasons` (`drop_re_id`),
  ADD CONSTRAINT `dropout_stu_ibfk_3` FOREIGN KEY (`aadhar_no`) REFERENCES `student` (`aadhar_no`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `school` (`school_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
