<?php
require('fpdf/fpdf.php');

// Extend the FPDF class to create custom header and footer
class PDF extends FPDF {
    // Page header
    function Header() {
        // Set font
        $this->SetFont('Arial', 'B', 12);
        // Title
        $this->Cell(0, 15, 'Dropout Report', 0, 1, 'C');
        // Line break
        $this->Ln(10);
    }

    // Page footer
    function Footer() {
       
    }
}

// Create a new PDF document
$pdf = new PDF();

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('Arial', '', 10);

// Fetch data from the ministry_dashboard page
include("./Database/DB.php");
session_start();
if (!isset($_SESSION['ministry_email'])) {
    header("Location: Ministry_login_1.php");
    exit();
}

// Query to fetch main data
$query_main = "SELECT dropout_reasons.reason, dropout_stu.dr_year, school.district, COUNT(DISTINCT dropout_stu.aadhar_no) AS dropout_students, COUNT(DISTINCT dropout_stu.school_id) AS schools_with_dropout FROM dropout_stu INNER JOIN school ON dropout_stu.school_id = school.school_id INNER JOIN student ON dropout_stu.aadhar_no = student.aadhar_no INNER JOIN dropout_reasons ON dropout_stu.drop_re_id = dropout_reasons.drop_re_id GROUP BY school.district, dropout_stu.dr_year, dropout_reasons.reason";

// Execute the main query
$result_main = mysqli_query($conn, $query_main);

// Add main data to PDF
if ($result_main) {
    // Set column widths for main table
    $mainDistrictWidth = 30;
    $mainYearWidth = 20;
    $mainReasonWidth = 70;
    $mainDropoutWidth = 45;
    $mainSchoolWidth = 30;

    // Start main table
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell($mainDistrictWidth, 10, 'District', 1, 0, 'C');
    $pdf->Cell($mainYearWidth, 10, 'Year', 1, 0, 'C');
    $pdf->Cell($mainReasonWidth, 10, 'Reason of Dropout', 1, 0, 'C');
    $pdf->Cell($mainDropoutWidth, 10, 'No. of Dropout Students', 1, 0, 'C');
    $pdf->Cell($mainSchoolWidth, 10, 'No of School', 1, 1, 'C');

    // Set font for main table data
    $pdf->SetFont('Arial', '', 10);

    while ($row = mysqli_fetch_assoc($result_main)) {
        // Add a row to the main table
        $pdf->Cell($mainDistrictWidth, 10, $row['district'], 1, 0, 'C');
        $pdf->Cell($mainYearWidth, 10, $row['dr_year'], 1, 0, 'C');
        $pdf->Cell($mainReasonWidth, 10, $row['reason'], 1, 0, 'C');
        $pdf->Cell($mainDropoutWidth, 10, $row['dropout_students'], 1, 0, 'C');
        $pdf->Cell($mainSchoolWidth, 10, $row['schools_with_dropout'], 1, 1, 'C');
    }
}

// Add a line break
$pdf->Ln(10);

// Query to fetch data for city-wise table
$query_city = "SELECT school.district, COUNT(DISTINCT dropout_stu.aadhar_no) AS dropout_students, COUNT(DISTINCT dropout_stu.school_id) AS schools_with_dropout FROM dropout_stu INNER JOIN school ON dropout_stu.school_id = school.school_id GROUP BY school.district";

// Execute the query for city-wise table
$result_city = mysqli_query($conn, $query_city);

// Print city-wise table
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 10, 'City Wise Dropout :', 0, 1, 'L');
$pdf->Ln(5); // Add some space after the title

// Start table for city-wise data
$cityDistrictWidth = 60;
$cityDropoutWidth = 60;
$citySchoolWidth = 60;

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell($cityDistrictWidth, 10, 'District', 1, 0, 'L');
$pdf->Cell($cityDropoutWidth, 10, 'No. of Dropout Students', 1, 0, 'C');
$pdf->Cell($citySchoolWidth, 10, 'No of School with Dropout', 1, 1, 'C');

$pdf->SetFont('Arial', '', 10);
while ($row = mysqli_fetch_assoc($result_city)) {
    // Add a row to the city-wise table
    $pdf->Cell($cityDistrictWidth, 10, $row['district'], 1, 0, 'C');
    $pdf->Cell($cityDropoutWidth, 10, $row['dropout_students'], 1, 0, 'C');
    $pdf->Cell($citySchoolWidth, 10, $row['schools_with_dropout'], 1, 1, 'C');
}

// Add a line break
$pdf->Ln(10);

// Query to fetch data for reason-wise table
$query_reason = "SELECT dropout_reasons.reason, COUNT(DISTINCT dropout_stu.aadhar_no) AS dropout_students, COUNT(DISTINCT dropout_stu.school_id) AS schools_with_dropout FROM dropout_stu INNER JOIN dropout_reasons ON dropout_stu.drop_re_id = dropout_reasons.drop_re_id GROUP BY dropout_reasons.reason";

// Execute the query for reason-wise table
$result_reason = mysqli_query($conn, $query_reason);

// Print reason-wise table
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 10, 'Reason Wise Dropout :', 0, 1, 'L');
$pdf->Ln(5); // Add some space after the title

// Start table for reason-wise data
$reasonReasonWidth = 60;
$reasonDropoutWidth = 60;
$reasonSchoolWidth = 60;

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell($reasonReasonWidth, 10, 'Reason of Dropout', 1, 0, 'C');
$pdf->Cell($reasonDropoutWidth, 10, 'No. of Dropout Students', 1, 0, 'C');
$pdf->Cell($reasonSchoolWidth, 10, 'No of School with Dropout', 1, 1, 'C');

$pdf->SetFont('Arial', '', 10);
while ($row = mysqli_fetch_assoc($result_reason)) {
    // Add a row to the reason-wise table
    $pdf->Cell($reasonReasonWidth, 10, $row['reason'], 1, 0, 'C');
    $pdf->Cell($reasonDropoutWidth, 10, $row['dropout_students'], 1, 0, 'C');
    $pdf->Cell($reasonSchoolWidth, 10, $row['schools_with_dropout'], 1, 1, 'C');
}

// Add a line break
$pdf->Ln(10);

// Query to fetch data for year-wise table
$query_year = "SELECT dropout_stu.dr_year, COUNT(DISTINCT dropout_stu.aadhar_no) AS dropout_students, COUNT(DISTINCT dropout_stu.school_id) AS schools_with_dropout FROM dropout_stu GROUP BY dropout_stu.dr_year";

// Execute the query for year-wise table
$result_year = mysqli_query($conn, $query_year);

// Print year-wise table
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 15, 'Year Wise Dropout :', 0, 1, 'L');
$pdf->Ln(5); // Add some space after the title

// Start table for year-wise data
$yearYearWidth = 20;
$yearDropoutWidth = 60;
$yearSchoolWidth = 60;

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell($yearYearWidth, 10, 'Year', 1, 0, 'C');
$pdf->Cell($yearDropoutWidth, 10, 'No. of Dropout Students', 1, 0, 'C');
$pdf->Cell($yearSchoolWidth, 10, 'No of School with Dropout', 1, 1, 'C');

$pdf->SetFont('Arial', '', 10);
while ($row = mysqli_fetch_assoc($result_year)) {
    // Add a row to the year-wise table
    $pdf->Cell($yearYearWidth, 10, $row['dr_year'], 1, 0, 'C');
    $pdf->Cell($yearDropoutWidth, 10, $row['dropout_students'], 1, 0, 'C');
    $pdf->Cell($yearSchoolWidth, 10, $row['schools_with_dropout'], 1, 1, 'C');
}

// Add a line break
$pdf->Ln(10);

// Print all dropout student details
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 10, 'All Dropout Student Details :', 0, 1, 'L');
$pdf->Ln(5); // Add some space after the title

// Query to fetch all dropout student details with school name
$query_all_dropout = "SELECT student.name, student.roll_no, student.district, school.name AS sname, dropout_stu.dr_year, dropout_reasons.reason 
                      FROM dropout_stu 
                      INNER JOIN student ON dropout_stu.aadhar_no = student.aadhar_no 
                      INNER JOIN school ON student.school_id = school.school_id 
                      INNER JOIN dropout_reasons ON dropout_stu.drop_re_id = dropout_reasons.drop_re_id";

// Execute the query for all dropout student details
$result_all_dropout = mysqli_query($conn, $query_all_dropout);

// Start table for all dropout student details
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(15, 10, 'Roll No', 1, 0, 'C');
$pdf->Cell(30, 10, 'Name', 1, 0, 'C');
$pdf->Cell(20, 10, 'District', 1, 0, 'C');
$pdf->Cell(53, 10, 'School Name', 1, 0, 'C');
$pdf->Cell(23, 10, 'Dropout Year', 1, 0, 'C');
$pdf->Cell(50, 10, 'Reason', 1, 1, 'C');

$pdf->SetFont('Arial', '', 10);
while ($row = mysqli_fetch_assoc($result_all_dropout)) {
    // Add a row to the all dropout student details table
    $pdf->Cell(15, 10, $row['roll_no'], 1, 0, 'C');
    $pdf->Cell(30, 10, $row['name'], 1, 0, 'C');
    $pdf->Cell(20, 10, $row['district'], 1, 0, 'C');
    $pdf->Cell(53, 10, $row['sname'], 1, 0, 'C');
    $pdf->Cell(23, 10, $row['dr_year'], 1, 0, 'C');
    $pdf->Cell(50, 10, $row['reason'], 1, 1, 'C');
}

// Output the PDF as a file (you can also use 'D' to force download)
$pdf->Output('dropout_report.pdf', 'I');

?>
