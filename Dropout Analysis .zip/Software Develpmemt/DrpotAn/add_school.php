<?php
include("./Database/DB.php");
session_start();
if (!isset($_SESSION['ministry_email'])) {
    header("Location: Ministry_login_1.php");
    exit();
}

if (isset($_POST['Submit'])) {
    $address = $_POST['address'];
    $district = $_POST['district'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone_no = $_POST['phone_no'];

    $query = "INSERT INTO school (address, district, name, email, phone_no) 
              VALUES ('$address', '$district', '$name', '$email', '$phone_no')";

    if (mysqli_query($conn, $query)) {
        // Data inserted successfully
        echo "<script>alert('New school added successfully');</script>";
    } else {
        // Error occurred
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
    }

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Add School</title>
</head>
<body>
    <div class="container">
        <h1 class="mt-5 mb-1">Add School</h1>
        <a href="Ministry_dashboard.php" class="btn btn-primary mt-3 mb-4">Back to Dashboard</a>
        <form action="add_school.php" method="post">
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="name" class="form-label">Name:</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="col-md-6">
                    <label for="district" class="form-label">District:</label>
                    <input type="text" class="form-control" id="district" name="district" required>
                </div>
            </div>
            <div class="mb-3">
                <label for="address" class="form-label">Address:</label>
                <textarea class="form-control" id="address" name="address" rows="2" required></textarea>
            </div>
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="email" class="form-label">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="col-md-6">
                    <label for="phone_no" class="form-label">Phone No:</label>
                    <input type="tel" class="form-control" id="phone_no" name="phone_no" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary" name="Submit">Submit</button>
        </form>
        
    </div>

    <!-- JavaScript libraries -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
