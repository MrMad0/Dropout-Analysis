-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2024 at 05:40 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dropoutanl`
--

-- --------------------------------------------------------

--
-- Table structure for table `dropout_reasons`
--

CREATE TABLE `dropout_reasons` (
  `drop_re_id` int(10) NOT NULL,
  `reason` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dropout_reasons`
--

INSERT INTO `dropout_reasons` (`drop_re_id`, `reason`) VALUES
(1, 'Financial Issues'),
(2, 'Health Issues'),
(3, 'Family Problems'),
(4, 'Lack of Interest'),
(5, 'Poor Academic Performance'),
(6, 'Transportation'),
(7, 'Peer Pressure'),
(8, 'Gender Biasing'),
(9, 'Mental Health Issues'),
(10, 'Physical Disabilities');

-- --------------------------------------------------------

--
-- Table structure for table `dropout_stu`
--

CREATE TABLE `dropout_stu` (
  `d_id` int(10) NOT NULL,
  `school_id` int(10) NOT NULL,
  `dr_year` int(10) NOT NULL,
  `aadhar_no` varchar(13) NOT NULL,
  `drop_re_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dropout_stu`
--

INSERT INTO `dropout_stu` (`d_id`, `school_id`, `dr_year`, `aadhar_no`, `drop_re_id`) VALUES
(19, 1, 2024, '586505920015', 1),
(20, 2, 2024, '874818749393', 1),
(21, 2, 2024, '876219608506', 2),
(22, 1, 2024, '459821596210', 3),
(23, 4, 2024, '979720498084', 1),
(24, 6, 2024, '458265256520', 5),
(25, 9, 2020, '789012345678', 9),
(26, 1, 2021, '345678901434', 4),
(27, 1, 2019, '234567810123', 10),
(29, 7, 2015, '234567890123', 6),
(30, 5, 2022, '432101234567', 6),
(31, 10, 2020, '987654321012', 10);

-- --------------------------------------------------------

--
-- Table structure for table `ministry`
--

CREATE TABLE `ministry` (
  `minist_id` int(10) NOT NULL,
  `email_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ministry`
--

INSERT INTO `ministry` (`minist_id`, `email_id`) VALUES
(1, 'kanthariyahimesh@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

CREATE TABLE `school` (
  `school_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_no` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `school`
--

INSERT INTO `school` (`school_id`, `name`, `district`, `address`, `email`, `phone_no`) VALUES
(1, 'St. Xavier Public School', 'Surat', '123 Street, City, State, India', 'kanthariyahimesh9098+one@gmail.com', 1234567890),
(2, 'City Montessori School', 'Vadodara', '456 Road, City, State, India', 'kanthariyahimesh9098+two@gmail.com', 2147483647),
(3, 'Delhi Public School', 'Ahmedabad', '789 Avenue, City, State, India', 'kanthariyahimesh9098+three@gmail.com', 2147483647),
(4, 'Lokmanya School', 'Surat', 'Rander, Surat', 'kanthariyahimesh9098+four@gmail.com', 2147483647),
(5, 'Sunshine Public School', 'Ahmedabad', '123, ABC Road, Ahmedabad, Gujarat', 'himeshkanthariya919+Sunshine@gmail.com', 9876543210),
(6, 'Bright Horizon School', 'Surat', '456, XYZ Street, Surat, Gujarat', 'himeshkanthariya919+BH@gmail.com', 9876543220),
(7, 'Green Valley International School', 'Vadodara', '789, PQR Lane, Vadodara, Gujarat', 'himeshkanthariya919+GVI@gmail.com', 9846543210),
(8, 'Millennium High School', 'Anand', '543, OPQ Street, Anand, Gujarat', 'himeshkanthariya919+Mil@gmail.com', 9012345678),
(9, 'Tapti Valley International School', 'Surat', '987, EFG Avenue, Surat, Gujarat', 'himeshkanthariya919+tapti@gmail.com', 8876543220),
(10, 'Fountainhead School', 'Patan', '210, GHI Road, Patan, Gujarat', 'himeshkanthariya919+F@gmail.com', 8076543220);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `aadhar_no` varchar(13) NOT NULL,
  `roll_no` varchar(255) NOT NULL,
  `school_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `d_o_b` date NOT NULL,
  `address` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `religion` varchar(255) NOT NULL,
  `caste` enum('SC','ST','OBC','General') NOT NULL,
  `standard` int(10) NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`aadhar_no`, `roll_no`, `school_id`, `name`, `d_o_b`, `address`, `district`, `religion`, `caste`, `standard`, `gender`, `status`) VALUES
('101234567890', '18', 6, 'Manav Desai', '2007-05-15', '543 WXY Road, Surat, Gujarat', 'Surat', 'Hindu', 'General', 9, 'Male', 'Active'),
('123456789012', '19', 7, 'Pooja Sharma', '2008-07-28', '210 GHI Avenue, Vadodara, Gujarat', 'Vadodara', 'Hindu', 'General', 8, 'Female', 'Active'),
('123456789022', '1', 1, 'Amit Patel', '2008-05-10', '456 ABC Street, Surat, Gujarat', 'Surat', 'Hindu', 'General', 8, 'Male', 'Active'),
('210123456789', '17', 6, 'Riya Patel', '2008-10-12', '765 TUV Street, Surat, Gujarat', 'Surat', 'Hindu', 'OBC', 8, 'Female', 'Active'),
('234567810123', '2', 1, 'Priya Shah', '2009-08-15', '789 XYZ Road, Surat, Gujarat', 'Surat', 'Hindu', 'OBC', 7, 'Female', 'Dropped'),
('234567890123', '20', 7, 'Kunal Patel', '2009-01-15', '543 JKL Street, Vadodara, Gujarat', 'Vadodara', 'Hindu', 'OBC', 6, 'Male', 'Dropped'),
('321012345678', '16', 6, 'Nehal Shah', '2009-03-25', '1098 RST Lane, Surat, Gujarat', 'Surat', 'Hindu', 'General', 7, 'Male', 'Active'),
('345678901234', '21', 7, 'Sneha Singh', '2007-11-05', '876 MNO Road, Vadodara, Gujarat', 'Vadodara', 'Hindu', 'OBC', 7, 'Female', 'Active'),
('345678901434', '3', 1, 'Rahul Desai', '2007-03-20', '321 PQR Lane, Surat, Gujarat', 'Surat', 'Hindu', 'OBC', 9, 'Male', 'Dropped'),
('432101234567', '15', 5, 'Jiya Singh', '2007-12-10', '876 MNO Road, Ahmedabad, Gujarat', 'Ahmedabad', 'Hindu', 'SC', 9, 'Female', 'Active'),
('456789012305', '4', 2, 'Neha Patel', '2009-06-25', '123 MNO Avenue, Vadodara, Gujarat', 'Vadodara', 'Hindu', 'OBC', 6, 'Female', 'Active'),
('456789012345', '22', 8, 'Raj Patel', '2008-09-18', '210 GHI Avenue, Anand, Gujarat', 'Anand', 'Hindu', 'OBC', 8, 'Male', 'Active'),
('458265256520', '37', 6, 'Maitri Kanthariya', '2008-01-30', 'Surat', 'Surat', 'Hindu', 'SC', 7, 'Female', 'Dropped'),
('459625607805', '32', 1, 'Amit Patel', '2005-11-10', '789, PQR Colony', 'Surat', 'Hindu', 'OBC', 4, 'Male', 'Active'),
('459821596210', '33', 1, 'Deepika Singh', '2006-08-03', '987, LMN Avenue', 'Surat', 'Hindu', 'SC', 5, 'Female', 'Dropped'),
('543210123456', '14', 5, 'Krishna Gupta', '2009-02-28', '543 JKL Street, Ahmedabad, Gujarat', 'Ahmedabad', 'Hindu', 'SC', 6, 'Male', 'Active'),
('567890023456', '5', 2, 'Vikram Singh', '2008-12-12', '456 QRS Street, Vadodara, Gujarat', 'Vadodara', 'Hindu', 'OBC', 8, 'Male', 'Active'),
('567890123456', '23', 8, 'Shreya Shah', '2009-04-05', '543 JKL Street, Anand, Gujarat', 'Anand', 'Hindu', 'SC', 6, 'Female', 'Active'),
('586505920015', '34', 1, 'Priya Sharma', '2006-02-28', '456, XYZ Road', 'Surat', 'Hindu', 'General', 3, 'Female', 'Dropped'),
('654321012345', '13', 5, 'Aryan Patel', '2008-08-08', '210 GHI Avenue, Ahmedabad, Gujarat', 'Ahmedabad', 'Hindu', 'OBC', 8, 'Male', 'Active'),
('678901230567', '6', 2, 'Priyanka Sharma', '2007-09-05', '789 UVW Road, Vadodara, Gujarat', 'Vadodara', 'Hindu', 'General', 7, 'Female', 'Active'),
('678901234567', '24', 8, 'Vishal Mehta', '2007-10-20', '876 MNO Road, Anand, Gujarat', 'Anand', 'Hindu', 'ST', 7, 'Male', 'Active'),
('765032101234', '12', 4, 'Ananya Desai', '2007-06-05', '543 WXY Road, Surat, Gujarat', 'Surat', 'Hindu', 'OBC', 7, 'Female', 'Active'),
('765432101234', '30', 10, 'Karan Mehta', '2007-05-25', '876 MNO Road, Patan, Gujarat', 'Patan', 'Hindu', 'SC', 7, 'Male', 'Active'),
('789012345670', '7', 3, 'Rohan Chauhan', '2007-02-18', '210 GHI Avenue, Ahmedabad, Gujarat', 'Ahmedabad', 'Hindu', 'SC', 9, 'Male', 'Active'),
('789012345678', '25', 9, 'Ritu Sharma', '2008-06-12', '1098 RST Lane, Surat, Gujarat', 'Surat', 'Hindu', 'General', 8, 'Female', 'Dropped'),
('874818749393', '31', 2, 'Ramesh Kumar', '2005-05-15', '123, ABC Street', 'Vadodara', 'Hindu', 'ST', 1, 'Male', 'Dropped'),
('876043210123', '29', 10, 'Pooja Patel', '2008-12-30', '543 JKL Street, Patan, Gujarat', 'Patan', 'Hindu', 'OBC', 8, 'Female', 'Active'),
('876219608506', '35', 2, 'Rajesh Gupta', '2005-04-20', '654, DEF Lane', 'Vadodara', 'Hindu', 'General', 4, 'Male', 'Dropped'),
('876543210123', '11', 4, 'Amit Shah', '2008-11-20', '765 TUV Street, Surat, Gujarat', 'Surat', 'Hindu', 'OBC', 8, 'Male', 'Active'),
('890123406789', '8', 3, 'Kritika Mehta', '2008-10-30', '543 JKL Street, Ahmedabad, Gujarat', 'Ahmedabad', 'Hindu', 'ST', 8, 'Female', 'Active'),
('890123456789', '26', 9, 'Rajat Patel', '2009-03-20', '765 TUV Street, Surat, Gujarat', 'Surat', 'Hindu', 'OBC', 6, 'Male', 'Active'),
('901034567890', '9', 3, 'Rajesh Shah', '2007-07-07', '876 MNO Road, Ahmedabad, Gujarat', 'Ahmedabad', 'Hindu', 'OBC', 9, 'Male', 'Active'),
('901234567890', '27', 9, 'Riya Desai', '2007-12-05', '543 WXY Road, Surat, Gujarat', 'Surat', 'Hindu', 'OBC', 7, 'Female', 'Active'),
('979720498084', '36', 4, 'himesh kanthariya', '2005-03-30', 'Jahangirpura', 'Surat', 'Hindu', 'SC', 10, 'Male', 'Dropped'),
('981654321012', '10', 4, 'Divya Trivedi', '2009-04-15', '1098 RST Lane, Surat, Gujarat', 'Surat', 'Hindu', 'General', 6, 'Female', 'Active'),
('987654321012', '28', 10, 'Rahul Shah', '2009-07-15', '210 GHI Avenue, Patan, Gujarat', 'Patan', 'Hindu', 'SC', 6, 'Male', 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dropout_reasons`
--
ALTER TABLE `dropout_reasons`
  ADD PRIMARY KEY (`drop_re_id`);

--
-- Indexes for table `dropout_stu`
--
ALTER TABLE `dropout_stu`
  ADD PRIMARY KEY (`d_id`),
  ADD KEY `school_no` (`school_id`),
  ADD KEY `drop_re_id` (`drop_re_id`),
  ADD KEY `aadhar_no` (`aadhar_no`);

--
-- Indexes for table `ministry`
--
ALTER TABLE `ministry`
  ADD PRIMARY KEY (`minist_id`);

--
-- Indexes for table `school`
--
ALTER TABLE `school`
  ADD PRIMARY KEY (`school_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`aadhar_no`),
  ADD UNIQUE KEY `roll_no` (`roll_no`),
  ADD UNIQUE KEY `aadhar_no` (`aadhar_no`),
  ADD KEY `school_id` (`school_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dropout_stu`
--
ALTER TABLE `dropout_stu`
  MODIFY `d_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `ministry`
--
ALTER TABLE `ministry`
  MODIFY `minist_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `school`
--
ALTER TABLE `school`
  MODIFY `school_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dropout_stu`
--
ALTER TABLE `dropout_stu`
  ADD CONSTRAINT `dropout_stu_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `school` (`school_id`),
  ADD CONSTRAINT `dropout_stu_ibfk_2` FOREIGN KEY (`drop_re_id`) REFERENCES `dropout_reasons` (`drop_re_id`),
  ADD CONSTRAINT `dropout_stu_ibfk_3` FOREIGN KEY (`aadhar_no`) REFERENCES `student` (`aadhar_no`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `school` (`school_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
