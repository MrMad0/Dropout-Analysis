<?php
session_start();
include("../Database/DB.php");
include("../email.php");
if (isset($_SESSION["school_email"])) {
    $schoolEmail = $_SESSION["school_email"];
    $otp = rand(100000, 999999);   
    $_SESSION["school_otp"] = $otp;
    if (sendOTP($schoolEmail, $otp)) {
        header("Location: School_login_3.php");
        exit();
    } else {
        echo 'Error sending OTP. Check your email sending function.';
    }
} else {
    echo 'Error occur. Session variable not set.';
}
?>
