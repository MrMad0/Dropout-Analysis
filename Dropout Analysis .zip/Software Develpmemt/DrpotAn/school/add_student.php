<?php
include("../Database/DB.php");
session_start();
if (!isset($_SESSION['school_email'])) {
    header("Location: School_login_1.php");
    exit();
}

// Retrieve the school's city based on the school's ID
$school_email = $_SESSION['school_email'];
$query_school_city = "SELECT district FROM school WHERE email = '$school_email'";
$result_school_city = mysqli_query($conn, $query_school_city);
$row_school_city = mysqli_fetch_assoc($result_school_city);
$school_city = $row_school_city['district'];

if (isset($_POST['Add'])) {
    // Retrieve school_id using the email stored in session
    $school_email = $_SESSION['school_email'];
    $query_school_id = "SELECT school_id FROM school WHERE email = '$school_email'";
    $result_school_id = mysqli_query($conn, $query_school_id);
    $row_school_id = mysqli_fetch_assoc($result_school_id);
    $school_id = $row_school_id['school_id'];

    // Retrieve form data   
    $roll_no = $_POST['roll_no'];
    $aadhar_no = $_POST['aadhar_no'];
    $name = $_POST['name'];
    $dob = $_POST['dob'];
    $address = $_POST['address'];
    // Use the school's city as the district
    $district = $school_city;
    $religion = $_POST['religion'];
    $caste = $_POST['caste'];
    $gender = $_POST['gender'];
    $standard = $_POST['standard'];

    // Insert data into the student table
    $query = "INSERT INTO student (aadhar_no, roll_no, school_id, name, d_o_b, address, district, religion,caste, gender,standard,status) 
              VALUES ( '$aadhar_no','$roll_no','$school_id', '$name', '$dob', '$address', '$district', '$religion','$caste','$gender', '$standard', 'Active')";

    if (mysqli_query($conn, $query)) {
        // Data inserted successfully
        echo "<script>alert('New record created successfully');</script>";
    } else {
        // Error occurred
        echo "<script>alert('Error: " . $query . "<br>" . mysqli_error($conn) . "');</script>";
    }

    // Close the database connection
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1 class="mt-5 mb-4">Add Student</h1>
    <a href="School_dashboard.php" class="btn btn-primary mb-3">Back to Dashboard</a>
    <form action="add_student.php" method="post">
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="roll_no" class="form-label">Roll No:</label>
                    <input type="text" class="form-control" id="roll_no" name="roll_no" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="aadhar_no" class="form-label">Aadhar No:</label>
                    <input type="number" class="form-control" id="aadhar_no" name="aadhar_no" required>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="name" class="form-label">Name:</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="dob" class="form-label">Date of Birth:</label>
                    <input type="date" class="form-control" id="dob" name="dob" required>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="address" class="form-label">Address:</label>
                    <textarea class="form-control" id="address" name="address" rows="2" required></textarea>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <!-- District field pre-filled with school's city -->
                    <label for="district" class="form-label">District:</label>
                    <input type="text" class="form-control" id="district" name="district" value="<?php echo $school_city; ?>" required readonly>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="standard" class="form-label">Standard:</label>
                    <input type="number" class="form-control" id="standard" name="standard" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="gender" class="form-label">Gender:</label>
                    <select class="form-select" id="gender" name="gender" required>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
    <div class="col-md-6">
        <div class="mb-3">
            <label for="religion" class="form-label">Religion:</label>
            <input type="text" class="form-control" id="religion" name="religion" required>
        </div>
    </div>
</div>

        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="caste" class="form-label">Caste:</label>
                    <select class="form-select" id="caste" name="caste" required>
                        <option value="SC">SC</option>
                        <option value="ST">ST</option>
                        <option value="OBC">OBC</option>
                        <option value="General">General</option>
                    </select>
                </div>
            </div>
        </div>
        <button type="submit" class="btn btn-primary" name="Add">Submit</button>
    </form>
</div>

</body>
</html>
