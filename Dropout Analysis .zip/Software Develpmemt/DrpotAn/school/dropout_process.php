<?php
session_start();
if (!isset($_SESSION['school_email'])) {
    header("HTTP/1.1 403 Forbidden");
    exit();
}

include("../Database/DB.php");

// Fetch school_id based on the session email
$school_email = $_SESSION['school_email'];
$query_school_id = "SELECT school_id FROM school WHERE email = '$school_email'";
$result_school_id = mysqli_query($conn, $query_school_id);
$row = mysqli_fetch_assoc($result_school_id);
$school_id = $row['school_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["roll_no"]) && isset($_POST["dropout_reason"])) {
    $roll_no = $_POST["roll_no"];
    $dropout_reason_id = $_POST["dropout_reason"];

    // Retrieve aadhar_no using roll_no
    $query_aadhar_no = "SELECT aadhar_no FROM student WHERE roll_no = '$roll_no'";
    $result_aadhar_no = mysqli_query($conn, $query_aadhar_no);
    $row = mysqli_fetch_assoc($result_aadhar_no);
    $aadhar_no = $row['aadhar_no'];

    // Update student status to "Dropped" in the database
    $query_update_status = "UPDATE student SET status = 'Dropped' WHERE roll_no = '$roll_no'";
    mysqli_query($conn, $query_update_status);

    // Insert dropout information into the dropout_stu table
    $dr_year = date("Y");
    $query_insert_dropout = "INSERT INTO dropout_stu (school_id, dr_year, aadhar_no, drop_re_id) VALUES ('$school_id', '$dr_year', '$aadhar_no', '$dropout_reason_id')";
    mysqli_query($conn, $query_insert_dropout);

    // Redirect back to the dashboard or any other page
    header("Location: School_dashboard.php");
    exit();
} else {
    header("HTTP/1.1 400 Bad Request");
    exit();
}
?>
