<?php
include("../Database/DB.php");
session_start();
if (!isset($_SESSION['school_email'])) {
    header("Location: School_login_1.php");
    exit();
}

if (isset($_GET['id'])) {
    $roll_no = $_GET['id'];

    // Fetch student data based on roll number
    $query_student = "SELECT * FROM student WHERE roll_no = '$roll_no'";
    $result_student = mysqli_query($conn, $query_student);
    $row_student = mysqli_fetch_assoc($result_student);

    // Check if form is submitted for update
    if (isset($_POST['update'])) {
        // Retrieve form data
        $aadhar_no = $_POST['aadhar_no'];
        $name = $_POST['name'];
        $dob = $_POST['dob'];
        $address = $_POST['address'];
        $district = $_POST['district'];
        $religion = $_POST['religion'];
        $gender = $_POST['gender'];

        // Update student information in the database
        $query_update = "UPDATE student SET aadhar_no = '$aadhar_no', name = '$name', d_o_b = '$dob', address = '$address', 
                         district = '$district', religion = '$religion', gender = '$gender' WHERE roll_no = '$roll_no'";

        if (mysqli_query($conn, $query_update)) {
            // Update successful
            echo "<script>alert('Student information updated successfully');</script>";
            echo "<script>window.location.href='School_Dashboard.php';</script>";
            exit();
        } else {
            // Error occurred during update
            echo "<script>alert('Error updating student information: " . mysqli_error($conn) . "');</script>";
        }
    }
} else {
    // No student ID provided
    echo "<script>alert('Student ID not provided');</script>";
    echo "<script>window.location.href='student_dashboard.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Student</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1 class="mt-5 mb-4">Update Student</h1>
    <a href="School_dashboard.php" class="btn btn-primary mb-3">Back to Dashboard</a>
    <form action="" method="post">
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="aadhar_no" class="form-label">Aadhar No:</label>
                    <input type="number" class="form-control" id="aadhar_no" name="aadhar_no" value="<?php echo $row_student['aadhar_no']; ?>" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="name" class="form-label">Name:</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo $row_student['name']; ?>" required>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="dob" class="form-label">Date of Birth:</label>
                    <input type="date" class="form-control" id="dob" name="dob" value="<?php echo $row_student['d_o_b']; ?>" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="address" class="form-label">Address:</label>
                    <textarea class="form-control" id="address" name="address" rows="3" required><?php echo $row_student['address']; ?></textarea>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="district" class="form-label">District:</label>
                    <input type="text" class="form-control" id="district" name="district" value="<?php echo $row_student['district']; ?>" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="religion" class="form-label">Religion:</label>
                    <input type="text" class="form-control" id="religion" name="religion" value="<?php echo $row_student['religion']; ?>" required>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="gender" class="form-label">Gender:</label>
                    <select class="form-select" id="gender" name="gender" required>
                        <option value="Male" <?php if ($row_student['gender'] == 'Male') echo 'selected'; ?>>Male</option>
                        <option value="Female" <?php if ($row_student['gender'] == 'Female') echo 'selected'; ?>>Female</option>
                        <option value="Other" <?php if ($row_student['gender'] == 'Other') echo 'selected'; ?>>Other</option>
                    </select>
                </div>
            </div>
        </div>
        <button type="submit" class="btn btn-primary" name="update">Update</button>
    </form>
</div>


</body>
</html>
