<?php
session_start();
if (!isset($_SESSION['school_email'])) {
    header("Location: School_login_1.php");
    exit();
}
$school_email = $_SESSION['school_email'];

include("../Database/DB.php");
$query_school_id = "SELECT school_id FROM school WHERE email = '$school_email'";
$result_school_id = mysqli_query($conn, $query_school_id);
$row_school_id = mysqli_fetch_assoc($result_school_id);
$school_id = $row_school_id['school_id'];

$query_standards = "SELECT DISTINCT standard FROM student";
$result_standards = mysqli_query($conn, $query_standards);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.css">
    <title>School Dashboard</title>
    <style>
        .table-responsive {
            display: none;
        }

        .table-responsive:target {
            display: block;
        }

        .card {
            text-decoration: none;
            color: inherit;
            margin-bottom: 20px; 
        }

        .card:hover {
            background-color: #f8f9fa;
        }

        .card-body {
            padding: 1.25rem;
        }

        .table {
            margin-bottom: 0; 
        }

        th, td {
            vertical-align: middle;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- First Div: Title -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">School Dashboard</a>
                <span class="navbar-text ml-auto"><?php echo $school_email; ?></span>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>
                    </ul>
                    
                </div>
                
            </div>
            
        </nav>
        
        <!-- Second Div: Standards in Card Form -->
        <div class="row mt-4">
            <?php
            while ($row_standard = mysqli_fetch_assoc($result_standards)) {
                echo '<div class="col-md-4">';
                echo '<a href="#table_' . $row_standard['standard'] . '" class="card">';
                echo '<div class="card-body">';
                echo '<h5 class="card-title">Standard ' . $row_standard['standard'] . '</h5>';
                echo '</div>';
                echo '</a>';
                echo '</div>';
            }
            ?>
        </div>
        
        <div class="row mt-4">
            <div class="col-md-12">
                <a href="add_student.php" class="btn btn-primary">Add Student</a>
            </div>
        </div>
        <!-- Third Div: Students Table (Initially Hidden) -->
        <?php
        mysqli_data_seek($result_standards, 0); 
        while ($row_standard = mysqli_fetch_assoc($result_standards)) {
            echo '<div class="table-responsive mt-4" id="table_' . $row_standard['standard'] . '">';
            echo '<table class="table table-striped">';
            echo '<thead>';
            echo '<tr>';
            echo '<th>Roll No</th>';
            echo '<th>Aadhar No</th>';
            echo '<th>Name</th>';
            echo '<th>Date of Birth</th>';
            echo '<th>Address</th>';
            echo '<th>District</th>';
            echo '<th>Religion</th>';
            echo '<th>Caste</th>';
            echo '<th>Gender</th>';
            echo '<th>Action</th>'; 
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';
            $query_students = "SELECT * FROM student WHERE standard = '{$row_standard['standard']}' AND status != 'Dropped' AND school_id ='$school_id'";
            $result_students = mysqli_query($conn, $query_students);
            while ($row_student = mysqli_fetch_assoc($result_students)) {
                echo '<tr>';
                echo '<td>' . $row_student['roll_no'] . '</td>';
                echo '<td>' . $row_student['aadhar_no'] . '</td>';
                echo '<td>' . $row_student['name'] . '</td>';
                echo '<td>' . $row_student['d_o_b'] . '</td>';
                echo '<td>' . $row_student['address'] . '</td>';
                echo '<td>' . $row_student['district'] . '</td>';
                echo '<td>' . $row_student['religion'] . '</td>';
                echo '<td>' . $row_student['caste'] . '</td>';
                echo '<td>' . $row_student['gender'] . '</td>';
                echo '<td>';
                echo '<a href="update_student.php?id=' . $row_student['roll_no'] . '" class="btn btn-primary btn-sm mr-2">Update</a>';
                echo '<a href="dropout_student.php?id=' . $row_student['roll_no'] . '" class="btn btn-danger btn-sm">Dropout</a>';
                echo '</td>';
                echo '</tr>';
            }
            echo '</tbody>';
            echo '</table>';
            echo '</div>';
        }
        ?>
    </div>
</body>
</html>
