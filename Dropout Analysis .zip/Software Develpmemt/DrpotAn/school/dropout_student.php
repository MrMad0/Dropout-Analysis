<?php
session_start();
if (!isset($_SESSION['school_email'])) {
    header("Location: School_login_1.php");
    exit();
}

include("../Database/DB.php");

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id"])) {
    $student_id = $_GET["id"];
    
    // Fetch student information from the database
    $query_student_info = "SELECT * FROM student WHERE roll_no = '$student_id'";
    $result_student_info = mysqli_query($conn, $query_student_info);
    $student_info = mysqli_fetch_assoc($result_student_info);
} else {
    // Redirect if no student ID is provided
    header("Location: School_dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Dropout Student</title>
</head>
<body>
    <div class="container">
        <h2>Dropout Student</h2>
        <a href="School_dashboard.php" class="btn btn-primary mb-3">Back to Dashboard</a>
        <form action="dropout_process.php" method="post">
            <div class="mb-3">
                <label for="roll_no" class="form-label">Roll No:</label>
                <input type="text" class="form-control" id="roll_no" name="roll_no" value="<?php echo $student_info['roll_no']; ?>" readonly>
            </div>
            <div class="mb-3">
                <label for="name" class="form-label">Name:</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo $student_info['name']; ?>" readonly>
            </div>
            <!-- Add other student information fields here -->

            <div class="mb-3">
                <label for="dropout_reason" class="form-label">Select Dropout Reason:</label>
                <select class="form-select" id="dropout_reason" name="dropout_reason">
                    <?php
                    // Fetch dropout reasons from the database
                    $query_dropout_reasons = "SELECT * FROM dropout_reasons";
                    $result_dropout_reasons = mysqli_query($conn, $query_dropout_reasons);
                    while ($row_reason = mysqli_fetch_assoc($result_dropout_reasons)) {
                        echo '<option value="' . $row_reason['drop_re_id'] . '">' . $row_reason['reason'] . '</option>';
                    }
                    ?>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Dropout</button>
        </form>
    </div>
</body>
</html>
